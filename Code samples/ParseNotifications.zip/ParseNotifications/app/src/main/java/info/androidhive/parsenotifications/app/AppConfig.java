package info.androidhive.parsenotifications.app;

/**
 * Created by Ravi on 15/05/15.
 */
public class AppConfig {
    public static final String PARSE_CHANNEL = "AndroidHive";
    public static final String PARSE_APPLICATION_ID = "";
    public static final String PARSE_CLIENT_KEY = "";
    public static final int NOTIFICATION_ID = 100;
}
