package com.harish.asynctask;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by jagadeesh on 23/8/17.
 */

public class BG_TASK extends AsyncTask<String,Void,String> {
    String response;
    Context context;

    public BG_TASK(MainActivity mainActivity) {
        this.context=mainActivity;
    }

    @Override
    protected String doInBackground(String... params) {
        String reg_url="https://androidfunda.000webhostapp.com/database.php";



        String method=params[0];
        if (method.equals("signup"));

        {

            String user=params[1];
            String password=params[2];

            try {
                URL url=new URL(reg_url);
                HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
                //type of method is post
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream OS=httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter=new BufferedWriter(new OutputStreamWriter(OS,"UTF-8"));

                //here name and pwd are present in database.php file
                String data= URLEncoder.encode("name","UTF-8") +"="+URLEncoder.encode(user,"UTF-8")+"&"+

                        URLEncoder.encode("pwd","UTF-8") +"="+ URLEncoder.encode(password,"UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                OS.close();
                InputStream Is=httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Is, "iso-8859-1"));
                response = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }
                bufferedReader.close();
                Is.close();
                return response;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }





        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if(s.equals("success")){
            Toast.makeText(context,s,Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context,"user already exists",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}
